//
//  Budget.swift
//  Project_Two
//
//  Created by Marco Worni on 29.01.2025.
//

import SwiftUI
import Foundation

struct Budget: Identifiable {
    var id: UUID
    var name: String
    var amount: Double
    var category: Category
    var parentCategoryId: UUID? // Falls `nil`, dann ist es eine Hauptkategorie
}
