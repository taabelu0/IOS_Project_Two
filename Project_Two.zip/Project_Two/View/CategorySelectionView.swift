//
//  CategorySelectionView.swift
//  Project_Two
//
//  Created by Marco Worni on 29.01.2025.
//
import SwiftUI

struct CategorySelectionView: View {
    @ObservedObject var viewModel: TransactionsViewModel
    var allowAllCategories: Bool // Steuerung, ob "All Categories" angezeigt wird

    var body: some View {
        VStack {
            Text("Select a Category")
                .font(.headline)
                .padding()

            List {
                // ✅ Falls die View "All Categories" erlauben soll (nur für Budgets)
                if allowAllCategories {
                    Button(action: {
                        viewModel.selectedCategory = nil
                        viewModel.showCategoryPicker = false
                    }) {
                        HStack {
                            Image(systemName: "circle")
                                .foregroundColor(.gray)
                            Text("All Categories")
                        }
                    }
                }

                // ✅ Parent Categories sortiert durchlaufen
                ForEach(Array(viewModel.parentCategories.keys).sorted(), id: \.self) { parent in
                    // 🔹 Finde alle Kategorien, die zur ParentCategory gehören
                    let filteredCategories = viewModel.categories.filter { $0.parentCategory == parent }

                    // ✅ **Nur anzeigen, wenn Kategorien existieren**
                    if !filteredCategories.isEmpty {
                        Section(header: Text(parent).foregroundColor(viewModel.parentCategories[parent])) {
                            ForEach(filteredCategories, id: \.id) { category in
                                HStack {
                                    Image(systemName: category.symbol)
                                        .foregroundColor(category.color)
                                    Text(category.name)
                                }
                                .contentShape(Rectangle()) // ✅ Klickbare Fläche erweitern
                                .onTapGesture {
                                    viewModel.selectedCategory = category
                                    viewModel.showCategoryPicker = false
                                }
                            }
                        }
                    }
                }
            }
        }
        .background(Color(UIColor.systemBackground))
        .cornerRadius(20)
    }
}
