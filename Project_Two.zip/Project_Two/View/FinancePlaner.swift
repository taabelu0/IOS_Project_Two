//
//  Project_TwoApp.swift
//  Project_Two
//
//  Created by Luca Bertonazzi on 25.01.2025.
//

import SwiftUI

@main
struct FinancePlaner: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
