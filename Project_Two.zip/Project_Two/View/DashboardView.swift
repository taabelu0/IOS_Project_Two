//
//  DashboardView.swift
//  Project_Two
//
//  Created by Luca Bertonazzi on 25.01.2025.
//
import SwiftUI

struct DashboardView: View {
    @ObservedObject var viewModel: TransactionsViewModel

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    HStack {
                        Button(action: {
                            viewModel.activeSheet = .filter
                        }) {
                            Image(systemName: "line.3.horizontal.decrease.circle")
                                .font(.title2)
                        }
                        .padding(.leading)
                        Spacer()
                        Text("Budgets for \(viewModel.selectedFilter == "All" ? "All Categories" : viewModel.selectedFilter)")
                            .font(.headline)
                        Spacer()
                    }
                    
                    BudgetPieChartView(viewModel: viewModel)
                    
                    Text("5 Most Expensive Transactions")
                        .font(.title2)
                        .bold()
                        .padding(.leading)
                    
                    if viewModel.filteredTransactions.isEmpty {
                        VStack {
                            Image(systemName: "tray.fill")
                                .font(.largeTitle)
                                .foregroundColor(.gray)
                                .padding(.bottom, 10)
                            
                            Text("No Transactions Available")
                                .font(.title2)
                                .foregroundColor(.gray)
                                .padding(.bottom, 5)
                            
                            Text("Tap the '+' button to add a transaction.")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        VStack(spacing: 10) {
                            let topTransactions = viewModel.filteredTransactions
                                .sorted(by: { $0.amount > $1.amount })
                                .prefix(5)
                            
                            ForEach(topTransactions, id: \ .id) { transaction in
                                HStack(alignment: .center) {
                                    Image(systemName: transaction.category.symbol)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 30, height: 30)
                                        .foregroundColor(transaction.category.color)
                                    
                                    VStack(alignment: .leading) {
                                        Text(transaction.name)
                                            .font(.headline)
                                        Text(transaction.category.name)
                                            .font(.subheadline)
                                            .foregroundColor(transaction.category.color)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.leading, 8)
                                    
                                    Spacer()
                                    
                                    Text(String(format: "$%.2f", transaction.amount))
                                        .foregroundColor(transaction.amount < 0 ? .red : .primary)
                                }
                                .padding(.vertical, 5)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    viewModel.startEditingTransaction(transaction)
                                }
                            }
                        }
                        .padding()
                    }
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Budget Overview")
                            .font(.title2)
                            .bold()
                        
                        HStack {
                            Text("Budget")
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Text("Total")
                                .bold()
                                .frame(maxWidth: .infinity)
                            Text("Remaining")
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                        .padding(.vertical, 5)
                        .padding(.horizontal, 4)
                        
                        ForEach(
                            (viewModel.selectedFilter == "All" ?
                             viewModel.budgets.filter { $0.parentCategoryId == nil } :
                            viewModel.budgets.filter { $0.parentCategoryId?.uuidString == viewModel.selectedFilter || $0.parentCategoryId == UUID(uuidString: viewModel.selectedFilter) }
                            ).sorted(by: { $0.amount > $1.amount }), id: \.id
                        ) { budget in
                            let spent = viewModel.totalForCategory(budget.category)
                            let remaining = budget.amount - spent
                            
                            HStack {
                                Text(budget.name)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                Text(String(format: "%.2f", budget.amount))
                                    .frame(maxWidth: .infinity)
                                Text(String(format: "%.2f", remaining))
                                    .foregroundColor(remaining < 0 ? .red : .green)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                            }
                            .padding(.vertical, 2)
                        }
                    }
                    .padding()
                }
                .padding()
            }
            .navigationTitle("Dashboard")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Text("Total: ")
                        .font(.headline)
                        .foregroundColor(viewModel.overallTotalBudget() < 0 ? .red : .primary)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Text(String(format: "$%.2f", viewModel.overallTotalBudget()))
                        .font(.headline)
                        .foregroundColor(viewModel.overallTotalBudget() < 0 ? .red : .primary)
                }
            }
        }
    }
}
